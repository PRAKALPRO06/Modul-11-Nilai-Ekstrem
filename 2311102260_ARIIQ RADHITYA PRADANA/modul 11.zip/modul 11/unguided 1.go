package main

import (
	"fmt"
)

func main() {
	var n int

	// Memasukkan jumlah anak kelinci
	fmt.Print("Masukkan jumlah anak kelinci: ")
	fmt.Scan(&n)

	// Validasi jumlah anak kelinci
	if n <= 0 || n > 1000 {
		fmt.Println("Jumlah anak kelinci harus di antara 1 dan 1000.")
		return
	}

	weights := make([]float64, n)

	// Memasukkan berat anak kelinci
	fmt.Println("Masukkan berat anak kelinci:")
	for i := 0; i < n; i++ {
		fmt.Scan(&weights[i])
	}

	// Mencari berat terkecil dan terbesar
	minWeight := weights[0]
	maxWeight := weights[0]

	for _, weight := range weights {
		if weight < minWeight {
			minWeight = weight
		}
		if weight > maxWeight {
			maxWeight = weight
		}
	}

	// Menampilkan hasil
	fmt.Printf("Berat terkecil: %.2f\n", minWeight)
	fmt.Printf("Berat terbesar: %.2f\n", maxWeight)
}
